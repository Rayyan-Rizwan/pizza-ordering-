// Navbar toggle
let menu = document.querySelector('#menu-icon');
let navbar = document.querySelector('.navbar');

menu.onclick = () => {
    navbar.classList.toggle('active');
}

window.onscroll = () => {
    navbar.classList.remove('active');
}

// Dark Mode
let darkmode = document.querySelector('#darkmode');
darkmode.onclick = () => {
    if(darkmode.classList.contains('bx-moon')){
        darkmode.classList.replace('bx-moon','bx-sun');
        document.body.classList.add('active');
    } else {
        darkmode.classList.replace('bx-sun','bx-moon');
        document.body.classList.remove('active');
    }
}

// Scroll Reveal
const sr = ScrollReveal({
    origin: 'top',
    distance: '40px',
    duration: 2000,
    reset: true
});

sr.reveal(`.home-text, .home-img,
           .about-img, .about-text,
           .box, .s-box,
           .btn, .connect-text,
           .contact-box`, { interval: 200 });

// Contact Form
// Contact Form
const contactForm = document.getElementById('contactForm');
const reply = document.getElementById('reply');

contactForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const contactNo = document.getElementById('contactNo').value;
    const location = document.getElementById('location').value;
    const message = document.getElementById('message').value;

    fetch('http://localhost:3000/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            name,
            email,
            contactNo,
            location,
            message
        })
    })
    .then(res => res.json())
    .then(data => {
        reply.textContent = data.success
            ? data.message
            : 'Failed to send message';

        if (data.success) contactForm.reset();
    })
    .catch(err => {
        reply.textContent = 'Error sending message';
        console.error(err);
    });
});
